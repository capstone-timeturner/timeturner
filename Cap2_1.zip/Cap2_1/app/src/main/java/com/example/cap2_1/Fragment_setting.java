package com.example.cap2_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;

public class Fragment_setting extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting, container, false);

        // 알람 on/off 설정 스위치
        //$$ Fragment에서 findviewbyid 참고 https://brightmango.tistory.com/39
        boolean isAlarmOn;
        Switch switch1 = (Switch)view.findViewById(R.id.switch1);

        CheckBox FTF_check1 = view.findViewById(R.id.FTF_check1);
        CheckBox FTF_check2 = view.findViewById(R.id.FTF_check2);
        CheckBox FTF_check3 = view.findViewById(R.id.FTF_check3);

        CheckBox NonC_check1 = view.findViewById(R.id.NonC_check1);
        CheckBox NonC_check2 = view.findViewById(R.id.NonC_check2);
        CheckBox NonC_check3 = view.findViewById(R.id.NonC_check3);

        CheckBox HW_check1 = view.findViewById(R.id.HW_check1);
        CheckBox HW_check2 = view.findViewById(R.id.HW_check2);
        CheckBox HW_check3 = view.findViewById(R.id.HW_check3);

        CheckBox sound_check = view.findViewById(R.id.sound_check);
        CheckBox vibrate_check = view.findViewById(R.id.vibrate_check);
        CheckBox popup_check = view.findViewById(R.id.popup_check);

        Button[] btns = {FTF_check1,FTF_check2,FTF_check3,NonC_check1,NonC_check2,NonC_check3,HW_check1,HW_check2,HW_check3,sound_check,vibrate_check,popup_check};





        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    for (int i = 0; i < 12; i++) {
                        btns[i].setEnabled(true);
                    }
                } else {
                    for (int i = 0; i < 12; i++) {
                        btns[i].setEnabled(false);
                    }
                }
            }
        });

        return view;


    }







}
