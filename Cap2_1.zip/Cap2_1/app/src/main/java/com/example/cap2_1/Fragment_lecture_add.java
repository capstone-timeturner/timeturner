package com.example.cap2_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;

public class Fragment_lecture_add extends Fragment {
    // 각각의 Fragment마다 Instance를 반환해 줄 메소드를 생성 static 값으로 다른 Fragment에서 사용
    static Fragment_lecture_add Fragment_lecture_add = new Fragment_lecture_add();

    public static Fragment_lecture_add newInstance() {
        return Fragment_lecture_add;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_lecture_add, container, false);


        // checked 결과 전달
        CheckBox class_add1 = view.findViewById(R.id.class_add1);
        CheckBox class_add2 = view.findViewById(R.id.class_add2);
        CheckBox class_add3 = view.findViewById(R.id.class_add3);
        CheckBox class_add4 = view.findViewById(R.id.class_add4);
        CheckBox class_add5 = view.findViewById(R.id.class_add5);
        CheckBox class_add6 = view.findViewById(R.id.class_add6);
        CheckBox class_add7 = view.findViewById(R.id.class_add7);
        CheckBox[] checkBoxes = {class_add1, class_add2, class_add3, class_add4, class_add5, class_add6, class_add7};

        boolean[] is_lec_checked = new boolean[7];


        // bundle 전달
        Button btn_done = view.findViewById(R.id.btn_done);

        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                for (int i = 0; i < 7; i++) {
                    is_lec_checked[i] = checkBoxes[i].isChecked();
                }
                Bundle bundle = new Bundle(); // 번들을 통해 값 전달
                bundle.putBooleanArray("is_lec_checked", is_lec_checked);//번들에 넘길 값 저장

                Fragment_lecture Fragment_lecture = MainActivity.Fragment_lecture;
                Fragment_lecture.setArguments(bundle);//번들을 프래그먼트로 보낼 준비

                Bundle is_lec_checkedBundle = new Bundle(); // 번들을 통해 값 전달
                bundle.putBooleanArray("is_lec_checkedBundle", is_lec_checked);//번들에 넘길 값 저장

                Fragment_timetable Fragment_timetable = MainActivity.Fragment_timetable;
                Fragment_timetable.setArguments(is_lec_checkedBundle);//번들을 프래그먼트로 보낼 준비


                // coursesBundle 받기  
                com.example.cap2_1.Fragment_lecture.Course[] checkedCourses= new Fragment_lecture.Course[7];
                com.example.cap2_1.Fragment_lecture.Course[] courses = new Fragment_lecture.Course[7];
                Bundle coursesBundle = getArguments();
                if (coursesBundle != null) {
                    courses = (com.example.cap2_1.Fragment_lecture.Course[]) bundle.getSerializable("coursesBundle");
                }
/*
                //checkedCourse
                for (int i = 0; i < 7; i++) {
                    if (is_lec_checked[i]) {
                        checkedCourses[i] = courses[i];
                    }
                }
                // checkedCourseBundle 보내기
                Bundle checkedCourseBundle = new Bundle(); // 번들을 통해 값 전달
                bundle.putBundle("checkedCourseBundle", checkedCourseBundle);//번들에 넘길 값 저장
                */


                ((MainActivity) getActivity()).replaceFragment(Fragment_lecture); //!!!!! newInstance하면 초기화되므로 그냥 전달


            }
        });


        return view;
    }

}