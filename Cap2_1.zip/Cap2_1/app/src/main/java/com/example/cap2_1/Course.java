package com.example.cap2_1;

public class Course {
    // 데이터베이스 참조

    String courseName;
    String courseTime;

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseTime() {
        return courseTime;
    }

    public void setCourseTime(String courseTime) {
        this.courseTime = courseTime;
    }

    public Course(String courseName, String courseTime) {
        this.courseName = courseName;
        this.courseTime = courseTime;
    } //constructor

}
