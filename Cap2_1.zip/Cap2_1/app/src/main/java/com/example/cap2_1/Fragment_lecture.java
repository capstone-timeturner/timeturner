package com.example.cap2_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.Serializable;


public class Fragment_lecture extends Fragment {

    // 강의 정보 샘플
    //Course.java
    public class Course {
        String CourseTitle, Lecturer, Field; //강의이름, 교수님이름, 이수영역
        int Grade, Credits; //학년, 학점
        int FTF; //대면수업 여부(0:비대면녹화, 1:비대면실시간, 2:대면)
        String[] Time = new String[6]; //강의 시간
        String[] Memo = {}; //자유메모
        int num  = 0; //강의 시간 추가에 사용

        Course(String CourseTitle, String Lecturer, String Field, int Grade, int Credits, int FTF){
            this.CourseTitle = CourseTitle;
            this.Lecturer = Lecturer;
            this.Field = Field;
            this.Grade = Grade;
            this.Credits = Credits;
            this.FTF = FTF;
        }
    }


    // 강의명을 눌렀을 때
    class BtnOnClickListener implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            ((MainActivity)getActivity()).replaceFragment(Fragment_lecture_list.newInstance());
        }
    }
    BtnOnClickListener myOnClickListener = new BtnOnClickListener();


    // 각각의 Fragment마다 Instance를 반환해 줄 메소드를 생성합니다.
    public static Fragment_lecture newInstance() {
        return new Fragment_lecture();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Timeturner.java : Course sample
        Course Multimedia = new Course("멀티미디어신호처리", "박규식","전공선택", 3, 3, 0);
        String[] Ctime = {"mon3","mon4","mon5","wed8","wed9","wed10"};
        for (int i=0;i<6;i++){
            Multimedia.Time[i] = Ctime[i];
            //Multimedia.setTime(Ctime[i]);
        }
        Course AI = new Course("인공지능", "이계성","전공선택", 3, 3, 1);
        String[] Ctime2 = {"tues3","tues4","tues5","thus3","thus4","thus5"};
        for (int i=0;i<6;i++){
            AI.Time[i] = Ctime2[i];
        }
        Course Adv_Database = new Course("고급데이터베이스", "오세종","전공선택", 3, 3, 2);
        String[] Ctime3 = {"thus8","thus9","thus10","fri8","fri9","fri10"};
        for (int i=0;i<6;i++){
            Adv_Database.Time[i] = Ctime3[i];
        }
        Course AI_Convergence = new Course("인공지능융합플랫폼", "이재동","전공선택", 3, 3, 2);
        String[] Ctime4 = {"fri11","fri12","fri13","fri14","fri15","fri16"};
        for (int i=0;i<6;i++){
            AI_Convergence.Time[i] = Ctime4[i];
        }
        Course Infor_Protction = new Course("정보보호이론", "박창섭","전공선택", 3, 3, 2);
        String[] Ctime5 = {"wed18","wed19","wed20"};
        for (int i=0;i<3;i++){
            Infor_Protction.Time[i] = Ctime5[i];
        }
        Course OpenSource_AI = new Course("오픈소스AI응용", "송영상","전공선택", 3, 3, 2);
        String[] Ctime6 = {"fri11","fri12","fri13","fri14","fri15","fri16"};
        for (int i=0;i<6;i++){
            OpenSource_AI.Time[i] = Ctime6[i];
        }
        Course OS_Security = new Course("운영체제보안", "조성제","전공선택", 3, 3, 2);
        String[] Ctime7 = {"tues11","tues12","tues13","wed11","wed12","wed13"};
        for (int i=0;i<6;i++){
            OS_Security.Time[i] = Ctime7[i];
        }

        //
        Course[] courses= {Multimedia, AI, Adv_Database, AI_Convergence, Infor_Protction, OpenSource_AI, OS_Security};
        Bundle coursesBundle = new Bundle(); // 번들을 통해 값 전달
        coursesBundle.putSerializable ("courses", courses);//번들에 넘길 값 저장, 객체는 Serializable 사용
        Fragment_lecture_add Fragment_lecture_add =  com.example.cap2_1.Fragment_lecture_add.newInstance();
        Fragment_lecture_add.setArguments(coursesBundle);//번들을 프래그먼트로 보낼 준비

        Fragment_timetable Fragment_timetable =  MainActivity.Fragment_timetable;
        Fragment_timetable.setArguments(coursesBundle);//번들을 프래그먼트로 보낼 준비


        View view = inflater.inflate(R.layout.fragment_lecture, null); // Fragment로 불러올 xml파일을 view로 가져옵니다.

        //// 동적 생성
        short count = 100;
        ViewGroup.LayoutParams layoutParams =
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT /* layout_width */, LinearLayout.LayoutParams.WRAP_CONTENT /* layout_height */);

        boolean[] is_lec_checked = {false, false, false, false, false, false, false};

        Bundle bundle = getArguments();
        if(bundle !=null) {
            is_lec_checked = bundle.getBooleanArray("is_lec_checked");
        }
        // add 에서 체크박스 받아오기
        LinearLayout layoutA = (LinearLayout) view.findViewById(R.id.cmdArea1);

        Button btn_lec0 = null;
        Button btn_lec1 = null;
        Button btn_lec2 = null;
        Button btn_lec3 = null;
        Button btn_lec4 = null;
        Button btn_lec5 = null;
        Button btn_lec6 = null;
        Button[] newBtn = {btn_lec0,btn_lec1,btn_lec2,btn_lec3,btn_lec4,btn_lec5,btn_lec6};

        TextView textView_lec0 = null;
        TextView textView_lec1 = null;
        TextView textView_lec2 = null;
        TextView textView_lec3 = null;
        TextView textView_lec4 = null;
        TextView textView_lec5 = null;
        TextView textView_lec6 = null;
        TextView[] newTvs= {textView_lec0,textView_lec1,textView_lec2,textView_lec3,textView_lec4,textView_lec5,textView_lec6};

        for(int i=0; i<7; i++){
            if(is_lec_checked[i]){
                newBtn[i]= new Button(this.getContext());
                newBtn[i].setId(count++);
                newBtn[i].setText(courses[i].CourseTitle);
                newBtn[i].setLayoutParams(layoutParams);

                newTvs[i]= new TextView(this.getContext());
                // 수업유형(0:비대면녹화, 1:비대면실시간, 2:대면)
                switch(courses[i].FTF) {
                    case 0:
                        newBtn[i].setBackgroundColor(getResources().getColor(R.color.color1));
                        newTvs[i].setText("비대면녹화");
                        break;
                    case 1:
                        newBtn[i].setBackgroundColor(getResources().getColor(R.color.color2));
                        newTvs[i].setText("비대면실시간");
                        break;
                    case 2:
                        newBtn[i].setBackgroundColor(getResources().getColor(R.color.color3));
                        newTvs[i].setText("대면");
                        break;
                    default:
                        break;
                }//switch
                layoutA.addView(newTvs[i]);
                layoutA.addView(newBtn[i]);
                newBtn[i].setOnClickListener(myOnClickListener);
            }

        }
        //// 동적 생성


        // +버튼을 눌렀을 때
        Button button1 = (Button)view.findViewById(R.id.btn_plus);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getActivity(): MainActivity의 replaceFragment 불러오기
                ((MainActivity)getActivity()).replaceFragment(Fragment_lecture_add.newInstance());//NewFragment.newInstance());    // 새로 불러올 Fragment의 Instance를 Main으로 전달
            }
        });

        return view;
    }

}

