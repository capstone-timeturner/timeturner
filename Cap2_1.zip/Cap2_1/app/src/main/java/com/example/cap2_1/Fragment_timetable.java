package com.example.cap2_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

public class Fragment_timetable extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_timetable, container, false);
        TextView text_timetableTitle = view.findViewById(R.id.text_timetableTitle);

        // is_lec_checked 받아오기
        boolean[] is_lec_checked = {false, false, false, false, false, false, false};

        Bundle bundle = getArguments();
        if(bundle !=null) {
            is_lec_checked = bundle.getBooleanArray("is_lec_checkedBundle");  // $$null값으로 들어온다. 문제
        }


        // coursesBundle 받기
        com.example.cap2_1.Fragment_lecture.Course[] checkedCourses= new Fragment_lecture.Course[7];
        com.example.cap2_1.Fragment_lecture.Course[] courses = new Fragment_lecture.Course[7];
        Bundle coursesBundle = getArguments();
        if (coursesBundle != null) {
            courses = (com.example.cap2_1.Fragment_lecture.Course[]) bundle.getSerializable("coursesBundle");
        }

        //checkedCourse
        for (int i = 0; i < 7; i++) {
            if (is_lec_checked!=null && is_lec_checked[i]) {
                //checkedCourses[i] = courses[i];
                text_timetableTitle.setText("is_lec_checked 얻음");
            }
        }


        /*
        // checkedCourse 받기
        com.example.cap2_1.Fragment_lecture.Course[] checkedCourse = new Fragment_lecture.Course[7];
        Bundle checkedCourseBundle = getArguments();
        if (checkedCourseBundle != null) {
            checkedCourse = (com.example.cap2_1.Fragment_lecture.Course[]) checkedCourseBundle.getParcelableArray("checkedCourseBundle");
        }

         */


        //$$ text_시간표 반영
/*
        for(com.example.cap2_1.Fragment_lecture.Course c :checkedCourse){
            text_timetableTitle.setText("c.toString()");
        }
       */
        text_timetableTitle.setText("c.toString()");


        return view;
    }
}