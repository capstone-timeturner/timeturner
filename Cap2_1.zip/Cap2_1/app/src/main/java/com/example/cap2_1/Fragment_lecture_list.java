package com.example.cap2_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class Fragment_lecture_list extends Fragment {

    // 각각의 Fragment마다 Instance를 반환해 줄 메소드를 생성합니다.
    public static Fragment_lecture_list newInstance() {
        return new Fragment_lecture_list();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_lecture_list, container, false);
        TextView detail_title = view.findViewById(R.id.detail_title);
        // detail_title.setText("Lecture name");

        TextView dev_text = view.findViewById(R.id.dev_text);
        // dev_text.setText("###교수");

        return view;
    }
}